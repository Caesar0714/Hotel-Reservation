package ui;

import api.AdminResource;
import api.HotelResource;
import model.IRoom;
import model.Room;
import model.RoomType;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AdminMenu {
    public static final AdminResource adminResource = AdminResource.getInstance();

    public static void startAdmin(){
        Scanner scan = new Scanner(System.in);
        printAdminMenu();
        int choice = scan.nextInt();
        while (choice != 5){
            switch(choice){
                case 1:
                    System.out.println(adminResource.getAllCustomers());
                    break;

                case 2:
                    System.out.println(adminResource.getAllRooms());
                    break;

                case 3:
                    adminResource.displayAllReservations();
                    break;

                case 4:
                    System.out.println("Enter room number");
                    // Get the room number
                    Scanner scan_1 = new Scanner(System.in);
                    String str_scan_1 = scan_1.nextLine();

                    System.out.println("Enter price per night");
                    // Get the room price
                    Scanner scan_2 = new Scanner(System.in);
                    Double dou_scan_2 = Double.valueOf(scan_2.nextLine());

                    System.out.println("Enter room type: 1 for single bed, 2 for the double bed");
                    // Get the room type
                    Scanner scan_3 = new Scanner(System.in);
                    String str_scan_3 = scan_3.nextLine();
                    RoomType roomType = null;
                    if (str_scan_3.equals("1")){
                        roomType = RoomType.SINGLE;
                    }
                    else if (str_scan_3.equals("2")){
                        roomType = RoomType.DOUBLE;
                    }
                    else{throw new IllegalArgumentException("Please enter a valid number");}
                    Room room = new Room(str_scan_1, dou_scan_2, roomType);

                    // Initialize a List of rooms
                    List<IRoom> rooms = new ArrayList<>();
                    rooms.add(room);
                    adminResource.addRoom(rooms);
                    break;

                case 5:
                    try {
                        MainMenu.startMain();
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    break;

                default:
                    System.out.println("This is an invalid selection");
                    break;
            }
            printAdminMenu();
            choice = scan.nextInt();
        }
        }


    public static void printAdminMenu(){
        System.out.println("1. See all Customers\n"+
                "2. See my Rooms\n"+
                "3. See all Reservations\n"+
                "4. Add a Room\n"+
                "5. Back to Main Menu\n"+
                "Please select a number for the menu option (1 ~ 5)");
    }
}
