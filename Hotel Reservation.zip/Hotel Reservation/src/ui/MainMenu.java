package ui;

import api.AdminResource;
import api.HotelResource;
import model.Customer;
import model.IRoom;
import model.Reservation;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {
    public static final HotelResource hotelResource = HotelResource.getInstance();

    public static void startMain() throws ParseException {
        Scanner scan = new Scanner(System.in);
        printMainMenu();
        int choice = scan.nextInt();
        while (choice != 5){
            switch(choice){
                case 1:
                    System.out.println("Enter CheckIn Date (mm-dd-yyyy)");
                    Scanner scan_in = new Scanner(System.in);
                    String checkin = scan_in.nextLine();
                    Date checkindate = new SimpleDateFormat("MM-dd-yyyy").parse(checkin);

                    System.out.println("Enter CheckOut Date (mm-dd-yyyy)");
                    Scanner scan_out = new Scanner(System.in);
                    String checkout = scan_out.nextLine();
                    Date checkoutdate = new SimpleDateFormat("MM-dd-yyyy").parse(checkout);

                    System.out.println(hotelResource.findARoom(checkindate,checkoutdate));
                    if (!hotelResource.findARoom(checkindate,checkoutdate).isEmpty()){
                        System.out.println("Would you like to book a room? y/n");
                        Scanner scan_1 = new Scanner(System.in);
                        String str_scan_1 = scan_1.nextLine();
                        if (str_scan_1.equals("y")){
                            System.out.println("Do you have an account with us? y/n");
                            Scanner scan_2 = new Scanner(System.in);
                            String str_scan_2 = scan_2.nextLine();
                            if (str_scan_2.equals("y")){
                                System.out.println("Enter Email format: name@domain.com");
                                // Get the customer email
                                Scanner scan_3 = new Scanner(System.in);
                                String str_scan_3 = scan_3.nextLine();
                                Customer customer = hotelResource.getCustomer(str_scan_3);
                                try{customer.equals(null);}
                                catch(Exception e){System.out.println("Please enter a valid email");break;}

                                System.out.println("What room number would you like to reserve?");
                                // Get the Reserved Room number
                                Scanner scan_4 = new Scanner(System.in);
                                String str_scan_4 = scan_4.nextLine();
                                IRoom room = hotelResource.getRoom(str_scan_4);
                                try{room.equals(null);}
                                catch(Exception e){System.out.println("Please enter a valid room number");break;}
                                Reservation reservation = hotelResource.bookARoom(str_scan_3,room,checkindate,checkoutdate);
                                System.out.println(reservation);
                            }
                            else if(str_scan_2.equals("n")){
                                System.out.println("Please create an account");
                                }
                            else {throw new IllegalArgumentException("Please enter a valid option");}
                        }
                        else if(str_scan_1.equals("n")){break;}

                        else {try{str_scan_1.equals(null);}
                              catch(Exception e){System.out.println("Please choose y or n");}
                            }
                    }
                    break;

                case 2:
                    System.out.println("Please enter your email below");
                    // Get the customer email
                    Scanner scan_5 = new Scanner(System.in);
                    String str_scan_5 = scan_5.nextLine();
                    Collection<Reservation> customer_reservation = hotelResource.getCustomersReservations(str_scan_5);
                    System.out.println(customer_reservation);
                    break;

                case 3:
                    System.out.println("Please enter an email that you want to create an account");
                    // Get the customer email
                    Scanner scan_6 = new Scanner(System.in);
                    String str_scan_6 = scan_6.nextLine();

                    System.out.println("Please enter your firstname");
                    // Get the customer's firstname
                    Scanner scan_7 = new Scanner(System.in);
                    String str_scan_7 = scan_7.nextLine();

                    System.out.println("Please enter your lastname");
                    // Get the customer lastname
                    Scanner scan_8 = new Scanner(System.in);
                    String str_scan_8 = scan_8.nextLine();

                    hotelResource.createACustomer(str_scan_6,str_scan_7,str_scan_8);
                    System.out.println("Your account is successfully created!");
                    break;

                case 4:
                    // Turn to admin menu
                    System.out.println("You're now enter into Admin Menu");
                    AdminMenu.startAdmin();
                    break;

                case 5:
                    System.exit(0);

                default:
                    System.out.println("This is an invalid selection");
                    break;

            }
            printMainMenu();
            choice = scan.nextInt();
        }
    }


    public static void printMainMenu(){
        System.out.println("1. Find and reserve a room\n"+
                "2. See my reservations\n"+
                "3. Create an account\n"+
                "4. Admin\n"+
                "5. Exit\n"+
                "Please select a number for the menu option (1 ~ 5)");

    }

    public static void main(String[] args){
        try {
            startMain();
        } catch (ParseException ex) {
            ex.getLocalizedMessage();
        }
    }

}
