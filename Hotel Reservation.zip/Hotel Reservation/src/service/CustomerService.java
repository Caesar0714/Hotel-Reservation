package service;

import model.Customer;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class CustomerService {
    Map<String, Customer> mapOfCustomer = new HashMap<String, Customer>();

    private static CustomerService customerService;
    private CustomerService(){}
    public static CustomerService getInstance(){
        if (null == customerService){
            customerService = new CustomerService();
        }
        return customerService;
    }

    public void addCustomer(String email, String firstName, String lastName){
        Customer customer = new Customer(email, firstName, lastName);
        mapOfCustomer.put(customer.getEmail(), customer);
    };

    public Customer getCustomer(String customerEmail){
        return mapOfCustomer.get(customerEmail);
    }

    public Collection<Customer> getAllCustomers(){
        return mapOfCustomer.values();
    }

}
