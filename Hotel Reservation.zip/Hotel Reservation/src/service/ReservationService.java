package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;


public class ReservationService {
    Collection<IRoom> setOfRoom = new HashSet<>();
    Collection<Reservation> setOfReservation = new HashSet<>();

    // Lazy initialization for Singleton Design Pattern
    private static ReservationService reservationService;
    private ReservationService(){}
    // method to return instance of class
    public static ReservationService getInstance(){
        if (null == reservationService){
            reservationService = new ReservationService();
        }
        return reservationService;
    }

    public void addRoom(IRoom room){
        setOfRoom.add(room);
    }

    public IRoom getARoom(String roomId){
        for (IRoom room: setOfRoom){
            if (roomId.equals(room.getRoomNumber())){
                return room;
            }
        }
        // when loop is completed and nothing is found
        return null;
    }

    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate){
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        setOfReservation.add(reservation);
        return reservation;
    }

    // find available rooms
    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate){
        Collection<IRoom> findAvailableRoom = new ArrayList<>();
        Collection<IRoom> findFullRoom = new ArrayList<>();
        Collection<IRoom> findRecommendRoom = new ArrayList<>();

        if (setOfRoom.isEmpty()){
            System.out.println("Sorry, we haven't created room right now");
        }
        else if (setOfReservation.isEmpty()){
            findAvailableRoom.addAll(setOfRoom);
        }
        else {
            // find available rooms that under reservation but in the booking range
            for (Reservation reservation : setOfReservation) {
                if (checkInDate.before(checkOutDate) && checkInDate.after(reservation.getCheckOutDate())
                        && setOfRoom.contains(reservation.getRoom())) {
                    findAvailableRoom.add(reservation.getRoom());
                } else if (checkInDate.before(checkOutDate) && checkInDate.before(reservation.getCheckOutDate())) {
                    findFullRoom.add(reservation.getRoom());
                }
            }
            // find unreserved rooms
            for (IRoom room : setOfRoom) {
                if (!findFullRoom.contains(room) && !findAvailableRoom.contains(room)) {
                    findAvailableRoom.add(room);
                }
            }

            // find whether there is available rooms
            if (findAvailableRoom.isEmpty()){
                // convert date to calendar
                Calendar cal_checkIn = Calendar.getInstance();
                cal_checkIn.setTime(checkInDate);
                // add 7 days
                cal_checkIn.add(Calendar.DATE, 7);
                // convert it back
                Date recommend_checkIn = cal_checkIn.getTime();

                Calendar cal_checkOut = Calendar.getInstance();
                cal_checkOut.setTime(checkOutDate);
                cal_checkOut.add(Calendar.DATE, 7);
                Date recommend_checkOut = cal_checkOut.getTime();


                // find available rooms that under reservation but in the recommended range
                for (Reservation full_reservation : setOfReservation) {
                    if (recommend_checkIn.after(full_reservation.getCheckOutDate()) && setOfRoom.contains(full_reservation.getRoom())) {
                        findRecommendRoom.add(full_reservation.getRoom());
                    }
                }
                if (findRecommendRoom.isEmpty()){
                    System.out.println("Sorry, there is no available room right now");
                }
                else{System.out.println("All rooms are reserved and our recommended rooms are shown below (+7 days on your origin range)");
                    return findRecommendRoom;}

            }

        }
        return findAvailableRoom;
    }

    public Collection<Reservation> getCustomersReservation(Customer customer){
        Collection<Reservation> customerReservation = new ArrayList<>();
        for (Reservation reservation: setOfReservation){
            if (reservation.getCustomer().equals(customer)){
                customerReservation.add(reservation);
            }
        }
        return customerReservation;
    }

    public void printAllReservation(){
        System.out.println(setOfReservation);
    }

    public Collection<IRoom> getSetOfRoom(){
        return setOfRoom;
    }

}
